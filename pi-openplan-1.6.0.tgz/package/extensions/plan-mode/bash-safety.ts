/**
 * Bash command safety guard for plan mode.
 *
 * Blocks destructive commands (rm, mv, git commit, npm install, etc.)
 * while allowing safe read-only commands (cat, grep, git status, etc.).
 */

// ── Patterns ────────────────────────────────────────────────────────────

const DESTRUCTIVE_PATTERNS = [
	/\brm\b/i,
	/\brmdir\b/i,
	/\bmv\b/i,
	/\bcp\b/i,
	/\bmkdir\b/i,
	/\btouch\b/i,
	/\bchmod\b/i,
	/\bchown\b/i,
	/\bchgrp\b/i,
	/\bln\s+-s\b/i,
	/\btee\b/i,
	/\btruncate\b/i,
	/\bdd\b/i,
	/\bshred\b/i,
	/\bsed\s+(.*\s+)?-i(\.[a-zA-Z]+)?\s/i,
	/\bnpm\s+(install|uninstall|update|ci|link|publish)/i,
	/\byarn\s+(add|remove|install|publish)/i,
	/\bpip\s+(install|uninstall)/i,
	/\bapt(-get)?\s+(install|remove|purge|update|upgrade)/i,
	/\bbrew\s+(install|uninstall|upgrade)/i,
	/\bgit\s+(add|commit|push|pull|merge|rebase|reset|checkout|stash|cherry-pick|revert|tag|init|clone)/i,
	/\bsudo\b/i,
	/\bsu\b/i,
	/\bkill\b/i,
	/\bpkill\b/i,
	/\bkillall\b/i,
	/\breboot\b/i,
	/\bshutdown\b/i,
	/\bsystemctl\s+(start|stop|restart|enable|disable)/i,
	/\bservice\s+\S+\s+(start|stop|restart)/i,
	/\b(vim?|nano|emacs|code|subl)\b/i,

	// Pipe-to-interpreter (dangerous: curl ... | bash)
	/\|\s*(ba)?sh\b/i,
	/\|\s*python\d?\b/i,
	/\|\s*perl\b/i,
	/\|\s*ruby\b/i,
	/\|\s*node\b/i,

	// Curl writing to files (any path, not just absolute)
	/\bcurl\b.*\s+-[a-zA-Z]*o\s/i,
	/\bcurl\b.*\s+--output\s/i,
	/\bcurl\b.*\s+-[a-zA-Z]*O\b/i,
	/\bcurl\b.*\s+--remote-name/i,

	// Curl sending data, forms, or uploading
	/\bcurl\b.*\s+-[a-zA-Z]*d\b/i,
	/\bcurl\b.*\s+--data/i,
	/\bcurl\b.*\s+-[a-zA-Z]*F\b/i,
	/\bcurl\b.*\s+--form/i,
	/\bcurl\b.*\s+-[a-zA-Z]*T\b/i,
	/\bcurl\b.*\s+--upload-file/i,

	// Curl non-safe method override
	/\bcurl\b.*\s+-[a-zA-Z]*X\s+(POST|PUT|DELETE|PATCH)\b/i,
	/\bcurl\b.*\s+--request\s+(POST|PUT|DELETE|PATCH)\b/i,

	// Wget writing to files (any path)
	/\bwget\s+.*-O\s+/i,
	/\bwget\s+.*--output-document\s+/i,
];

const SAFE_PATTERNS = [
	/^\s*cat\b/,
	/^\s*head\b/,
	/^\s*tail\b/,
	/^\s*less\b/,
	/^\s*more\b/,
	/^\s*grep\b/,
	/^\s*find\b/,
	/^\s*ls\b/,
	/^\s*pwd\b/,
	/^\s*echo\b/,
	/^\s*printf\b/,
	/^\s*wc\b/,
	/^\s*sort\b/,
	/^\s*uniq\b/,
	/^\s*diff\b/,
	/^\s*file\b/,
	/^\s*stat\b/,
	/^\s*du\b/,
	/^\s*df\b/,
	/^\s*tree\b/,
	/^\s*which\b/,
	/^\s*whereis\b/,
	/^\s*type\b/,
	/^\s*env\b/,
	/^\s*printenv\b/,
	/^\s*uname\b/,
	/^\s*whoami\b/,
	/^\s*id\b/,
	/^\s*date\b/,
	/^\s*cal\b/,
	/^\s*uptime\b/,
	/^\s*ps\b/,
	/^\s*top\b/,
	/^\s*htop\b/,
	/^\s*free\b/,
	/^\s*git\s+(status|log|diff|show|branch|remote|config\s+--get)/i,
	/^\s*git\s+ls-/i,
	/^\s*npm\s+(list|ls|view|info|search|outdated|audit)/i,
	/^\s*yarn\s+(list|info|why|audit)/i,
	/^\s*node\s+--version/i,
	/^\s*python\s+--version/i,
	/^\s*curl\s+(?!.*(?:-[a-zA-Z]*[oOdDFxXTuU]\b|--(?:output|remote-name|data|form|request|upload-file|cookie-jar|config)))/i,
	/^\s*wget\s+-O\s*-/i,
	/^\s*jq\b/,
	/^\s*sed\s+-n/i,
	/^\s*awk\b/,
	/^\s*rg\b/,
	/^\s*fd\b/,
	/^\s*bat\b/,
	/^\s*eza\b/,
	/^\s*make\s+(test|test-cov|shell|logs)/i,
	/^\s*cd\b/i,
];

// ── Guard ────────────────────────────────────────────────────────────────

/**
 * Check if a shell command is safe to run in plan mode.
 * Returns true if the command matches a known safe pattern and no destructive pattern.
 */
export function isSafeCommand(command: string): boolean {
	const isDestructive = DESTRUCTIVE_PATTERNS.some((p) => p.test(command));
	const isSafe = SAFE_PATTERNS.some((p) => p.test(command));
	return !isDestructive && isSafe;
}
